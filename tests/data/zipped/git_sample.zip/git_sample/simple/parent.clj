(ns parent)

;; a comment!
(do
  (prn "wow")
  (prn "gosh")
  egad)